<footer id="section-footer" class="footer moto-section" data-widget="section" data-container="section"
        data-moto-sticky="{mode:'smallHeight', direction:'bottom'}">
    <div class="moto-widget moto-widget-container moto-container_footer_584027aa83725" data-widget="container"
         data-container="container" data-css-name="moto-container_footer_584027aa83725">
        <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto"
             data-widget="row" data-spacing="lala">
            <div class="container-fluid">
                <div class="row">
                    <div class="moto-cell col-sm-3" data-container="container">
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aama">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                        class="moto-text_system_14">Навигация по разделам</p></div>
                        </div>
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aasa">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_201"><a
                                            href="upload" data-action="page" data-id="9" class="moto-link">Загрузка документов</a>​​​​​​​
                                </p></div>
                        </div>
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aasa">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_201"><a
                                            href="#about" data-action="page" data-id="10" class="moto-link">О нас</a>​​​​​​​
                                </p></div>
                        </div>
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aasa">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_201"><a
                                            href="#contact" data-action="page" data-id="11"
                                            class="moto-link">Контакты</a>​​​​​​​</p></div>
                        </div>
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aasa">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_201"><a
                                            href="#uslugi" data-action="blog.index" data-id="3"
                                            class="moto-link">Услуги</a>​​​​​​​</p></div>
                        </div>

                    </div>
                    <div class="moto-cell col-sm-4" data-container="container">
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aama">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                        class="moto-text_system_14">Контакты</p></div>
                        </div>
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="row" data-spacing="aasa" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-1" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da54f1f"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                        <span class="moto-widget-image-link">
                <img data-src="{{asset('images')}}/mt-0756_footer_icon01.png" class="moto-widget-image-picture lazyload"
                     data-id="160" title="" alt="">
            </span>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-11" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201"><a data-cke-saved-href="#" href="#"
                                                                                 target="_self" data-action="url"
                                                                                 class="moto-link">Краснодарский край, с.Успенское ул. Крупской 35</a>​​​​​​​</p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="row" data-spacing="aasa" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-1" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da551ae"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                        <span class="moto-widget-image-link">
                <img data-src="{{asset('images')}}/mt-0756_footer_icon02.png" class="moto-widget-image-picture lazyload"
                     data-id="161" title="" alt="">
            </span>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-11" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201"><a data-cke-saved-href="tel:+79186321007"
                                                                                 href="tel:+79186321007" target="_self"
                                                                                 data-action="url" class="moto-link">+79186321007</a>​​​​​​​
                                                </p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="moto-widget moto-widget-row moto-justify-content_center row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="row" data-spacing="aasa" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-1" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da55481"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                        <span class="moto-widget-image-link">
                <img data-src="{{asset('images')}}/mt-0756_footer_icon03.png" class="moto-widget-image-picture lazyload"
                     data-id="163" title="" alt="">
            </span>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-11" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201"><a
                                                            data-cke-saved-href="mailto:info@demolink.org"
                                                            href="mailto:info@demolink.org" data-action="mail"
                                                            class="moto-link">info@demolink.org</a>​​​​​​​</p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="row" data-spacing="aama" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-1" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da55669"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                        <span class="moto-widget-image-link">
                <img data-src="{{asset('images')}}/mt-0756_footer_icon04.png" class="moto-widget-image-picture lazyload"
                     data-id="162" title="" alt="">
            </span>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-11" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201">7 дней в неделю с 9:00  до 18:00 </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="moto-cell col-sm-2" data-container="container">
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aama">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                        class="moto-text_system_14">Мы в соцсетях</p></div>
                        </div>
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="row" data-spacing="aasa" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-2" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da55859"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                                            <a class="moto-widget-image-link moto-link"
                                               href="http://demolink.motocms.com/" data-action="url">
                                                <img data-src="{{asset('images')}}/mt-0756_footer_icon05.png"
                                                     class="moto-widget-image-picture lazyload" data-id="164" title=""
                                                     alt="">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-10" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201"><a href="http://demolink.motocms.com/"
                                                                                 target="_self" data-action="url"
                                                                                 class="moto-link">Facebook</a>​​​​​​​
                                                </p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                             data-widget="row" data-spacing="aasa" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-2" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da55a5d"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                                            <a class="moto-widget-image-link moto-link"
                                               href="http://demolink.motocms.com/" data-action="url">
                                                <img data-src="{{asset('images')}}/mt-0756_footer_icon06.png"
                                                     class="moto-widget-image-picture lazyload" data-id="165" title=""
                                                     alt="">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-10" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201"><a href="http://demolink.motocms.com/"
                                                                                 target="_self" data-action="url"
                                                                                 class="moto-link">Twitter</a>​​​​​​​
                                                </p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="row" data-spacing="aama" data-grid-type="xs">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-2" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da55d43"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                                            <a class="moto-widget-image-link moto-link"
                                               href="http://demolink.motocms.com/" data-action="url">
                                                <img data-src="{{asset('images')}}/mt-0756_footer_icon07.png"
                                                     class="moto-widget-image-picture lazyload" data-id="166" title=""
                                                     alt="">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-10" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                             data-widget="text" data-preset="default" data-spacing="aaas">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_201"><a href="http://demolink.motocms.com/"
                                                                                 target="_self" data-action="url"
                                                                                 class="moto-link">Google +</a>​​​​​​​
                                                </p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="moto-cell col-sm-3" data-container="container">
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aama">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                        class="moto-text_system_14">О нас</p></div>
                        </div>
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto"
                             data-widget="text" data-preset="default">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                        class="moto-text_system_11">“Третий год мы работаем для того чтобы вы могли быстро
                                    и удобно застраховать свое имущество. Наша компания предоставляет услуги по страхованию недвижимости,
                                    автострахованию(осаго, каско, оформление диагностической карты). </p></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="moto-widget moto-widget-container moto-container_footer_584027aa844cd" data-widget="container"
         data-container="container" data-css-name="moto-container_footer_584027aa844cd" data-draggable-disabled="">
        <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
             data-widget="row" data-spacing="sasa" data-draggable-disabled="">
            <div class="container-fluid">
                <div class="row">
                    <div class="moto-cell col-sm-6" data-container="container">
                        <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center"
                             data-widget="row" data-grid-type="xs" data-draggable-disabled="">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="moto-cell col-xs-1" data-container="container">
                                        <div data-widget-id="wid__image__5b7283da56073"
                                             class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                             data-widget="image">
                                            <a class="moto-widget-image-link moto-link" href="/" data-action="page">
                                                <img data-src="{{asset('images')}}/mt-0756_footer_logo.png"
                                                     class="moto-widget-image-picture lazyload" data-id="167" title=""
                                                     alt="">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="moto-cell col-xs-11" data-container="container">
                                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto"
                                             data-widget="text" data-preset="default" data-draggable-disabled="">
                                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                                        class="moto-text_202"><strong><span class="moto-color5_5">Автострахование <span
                                                                    style="font-size:12px;">© 2018.&nbsp; <a
                                                                        data-cke-saved-href="/0701-0800/mt-0756/privacy-policy/"
                                                                        href="/privacy-policy/" data-action="page"
                                                                        data-id="13"
                                                                        class="moto-link">By Dmitry Safonov</a></span></span></strong><br>
                                                </p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="moto-cell col-sm-6" data-container="container"></div>
                </div>
            </div>
        </div>
    </div>
</footer>