@if ((\Illuminate\Support\Facades\Request::path() != '/') and (\Illuminate\Support\Facades\Request::path() != 'contacts'))
    <link rel='stylesheet' id='style-css'  href="{{asset('css')}}/style1O.css" type='text/css' media='all' />
@endif


<link rel="stylesheet" href="{{asset('css')}}/assets.min.css"/>
<link rel="stylesheet" href="{{asset('css')}}/styles.css"/>
<style>
    @import url(//fonts.googleapis.com/css?family=Montserrat:regular,700|Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic&subset=latin,greek,cyrillic,cyrillic-ext,greek-ext,latin-ext,vietnamese);
</style>
<link rel="stylesheet" href="{{asset('css')}}/styles_2.css" id="moto-website-style"/>

