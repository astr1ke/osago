<!DOCTYPE html>
<html lang="en" data-ng-app="website">

    <head>

        <meta charset="utf-8">
        <title>Страхование в Успенском районе</title>
        <link rel="SHORTCUT ICON" href="/mt-demo/59400/59414/mt-content/uploads/2016/12/favicon.ico?_build=1534230153" type="image/vnd.microsoft.icon" />


        <link rel="canonical" href="https://template59414.motopreview.com/" />
        <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <?php echo $__env->make('layout.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </head>

    <body class="moto-background">
        <div class="page">

        <?php if(\Illuminate\Support\Facades\Request::path() == '/'): ?>
            <?php echo $__env->make('layout.headerWelcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif(\Illuminate\Support\Facades\Request::path() == 'contact'): ?>
            <?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('layout.headerUpload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>

        </div>
        <?php if(\Illuminate\Support\Facades\Request::path() == '/' or \Illuminate\Support\Facades\Request::path() == 'contacts' ): ?>
            <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

            <div data-moto-back-to-top-button class="moto-back-to-top-button">
                <a ng-click="toTop($event)" class="moto-back-to-top-button-link">
                    <span class="moto-back-to-top-button-icon fa"></span>
                </a>
            </div>

        <?php echo $__env->make('layout.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('js'); ?>

    </body>

</html>