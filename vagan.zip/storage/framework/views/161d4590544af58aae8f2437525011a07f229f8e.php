<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->

<head>

<body ng-app="angNewsApp">
<div >
    <h2>Single</h2>
    <input id="inputImage" type="file" accept="image/*" ng-model="image1" image="image1" resize-max-height="800" resize-max-width="800" resize-quality="0.7" resize-type="image/jpg" ng-image-compress/>
    <img ng-src="{{image1.compressed.dataURL}}" />

    <h2>Multiple</h2>
    <input id="inputImage" type="file" accept="image/*" ng-model="imageList" image="imageList" resize-max-height="800" resize-max-width="800" resize-quality="0.7" resize-type="image/jpg" multiple="multiple" ng-image-compress/>
    <div>
        <img ng-src="{{item.compressed.dataURL" ng-repeat="item in imageList}}" />
    </div>

<!-- just do a console.log of to see what other options are in the file object -->
</div>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.29/angular.min.js"></script>
<script src="js/app1.js"></script>
<script src="js/angular-image-compress.js"></script>
</body>

</html>