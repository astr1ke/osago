<script src="<?php echo e(asset('js')); ?>/website.assets.min.js" type="text/javascript" data-cfasync="false"></script>
<script type="text/javascript" data-cfasync="false">
    var websiteConfig = websiteConfig || {};
    websiteConfig.address = 'https://template59414.motopreview.com/';
    websiteConfig.addressHash = 'd74aaac9fc89e0403dbdf24079b62937';
    websiteConfig.apiUrl = '/api.php';
    websiteConfig.preferredLocale = 'en_US';
    websiteConfig.preferredLanguage = websiteConfig.preferredLocale.substring(0, 2);
    websiteConfig.back_to_top_button = {"topOffset":300,"animationTime":500,"type":"theme"};
    websiteConfig.popup_preferences = {"loading_error_message":"The content could not be loaded."};
    websiteConfig.lazy_loading = {"enabled":true};
    websiteConfig.cookie_notification = {"enabled":false,"content":"<p class=\"moto-text_normal\">This website uses cookies to ensure you get the best experience on our website.<\/p>","content_hash":"6200d081e0d72ab7f5a8fe78d961c3ec"};
    angular.module('website.plugins', []);
</script>
<script src="<?php echo e(asset('js')); ?>/website.min.js" type="text/javascript" data-cfasync="false"></script>
<script src="<?php echo e(asset('js')); ?>/jquery.js"></script>