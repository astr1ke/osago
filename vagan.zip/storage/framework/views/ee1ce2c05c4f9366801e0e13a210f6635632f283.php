
<?php $__env->startSection('content'); ?>
    <section id="section-content" class="content page-12 moto-section" data-widget="section" data-container="section">
        <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto"
             data-widget="row" data-spacing="lala">
            <div class="container-fluid">
                <div class="row">
                    <div class="moto-cell col-sm-12" data-container="container">
                        <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                             data-widget="text" data-preset="default" data-spacing="aama">
                            <div class="moto-widget-text-content moto-widget-text-editable"><p
                                        style="text-align: center;" class="moto-text_system_5">Contact us</p></div>
                        </div>
                        <div class="moto-widget moto-widget-map moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto"
                             data-widget="map" data-preset="default" data-spacing="aaaa" data-width="100">
                            <div class="moto-widget-cover"></div>
                            <iframe class="moto-widget-map-frame" width="100%" height="200"
                                    style="border: 0px; height: 640px; width: 100%;"
                                    src="//maps.google.com/maps?q=Glasgow&amp;z=15&amp;t=m&amp;output=embed"
                                    data-address="Glasgow" data-zoom="15"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="moto-widget moto-widget-container moto-container_content_5840697711" data-widget="container"
             data-container="container" data-css-name="moto-container_content_5840697711">
            <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto"
                 data-widget="row" data-spacing="lala">
                <div class="container-fluid">
                    <div class="row">
                        <div class="moto-cell col-sm-4" data-container="container">
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_system_5">Addresses</p></div>
                            </div>
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aasa">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_system_7">Address 1:</p></div>
                            </div>
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_normal">9870 St Vincent Place, Glasgow, DC 45 Fr
                                        45.&nbsp;</p></div>
                            </div>
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_system_7">Phones:</p></div>
                            </div>
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_normal"><a href="callto:#" target="_self" data-action="url"
                                                                        class="moto-link">+1 800 559 6580 </a> <br></p>
                                    <p class="moto-text_normal"><a href="callto:#" target="_self" data-action="url"
                                                                   class="moto-link">+1 800 603 6035</a>​​​​​​​</p>
                                </div>
                            </div>
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_system_7">Address 2:</p></div>
                            </div>
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_normal">9863 - 9867 Mill Road, Cambridge, MG09 99HT.</p>
                                </div>
                            </div>
                        </div>
                        <div class="moto-cell col-sm-8" data-container="container">
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto"
                                 data-widget="text" data-preset="default" data-spacing="aama">
                                <div class="moto-widget-text-content moto-widget-text-editable"><p
                                            class="moto-text_system_5">Contact form</p></div>
                            </div>
                            <div data-widget-id="wid__contact_form__5b72b8056d2e1"
                                 class="moto-widget moto-widget-contact_form moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                 data-preset="default" data-widget="contact_form" data-spacing="aaaa">
                                <div ng-controller="widget.ContactForm.Controller"
                                     ng-init="hash = '2@eyJoIjoiTlhhSFlpQWM2aUIrNnpZVWRuXC9MTmpIKzROQmpFUlwvNEJNWTMwVmZ4U3FZPSIsImkiOiI5d1lZSWJBV0M3bW40T2VIV2h1ZnlBPT0iLCJ2IjoiSU5VYkZUOEFURVB1emF3eUVFaHZmRDNlOFNNWDRabVlpQ0lISFpmVGJRMUE0dnB3NGYyZjNhcWtKd0U2WVQwRVdOVGlCVU5KRkc0bityYWluekJtTEE9PSJ9';actionAfterSubmission={&quot;action&quot;:&quot;none&quot;,&quot;url&quot;:&quot;&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;id&quot;:&quot;&quot;}">
                                    <form class="moto-widget-contact_form-form" role="form" name="contactForm"
                                          ng-submit="submit()" novalidate>
                                        <div ng-show="sending" class="contact-form-loading"></div>

                                        <div class="moto-widget-contact_form-group">
                                            <label for="field_name" class="moto-widget-contact_form-label">Your full
                                                name here:</label>
                                            <input type="text"
                                                   class="moto-widget-contact_form-field moto-widget-contact_form-input"
                                                   placeholder="Your full name here: *" ng-blur="validate('name')"
                                                   required ng-model-options="{ updateOn: 'blur' }" name="name"
                                                   id="field_name" ng-model="message.name"/>
                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak
                                                  ng-show="contactForm.name.$invalid && !contactForm.name.$pristine && !contactForm.name.emailInvalid">Field is required</span>
                                        </div>

                                        <div class="moto-widget-contact_form-group">
                                            <label for="field_email" class="moto-widget-contact_form-label">Enter your
                                                e-mail:</label>
                                            <input type="text"
                                                   class="moto-widget-contact_form-field moto-widget-contact_form-input"
                                                   placeholder="Enter your e-mail: *" ng-blur="validate('email')"
                                                   required ng-model-options="{ updateOn: 'blur' }" name="email"
                                                   id="field_email" ng-model="message.email"/>
                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak
                                                  ng-show="contactForm.email.$invalid && !contactForm.email.$pristine && !contactForm.email.emailInvalid">Field is required</span>
                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak
                                                  ng-show="contactForm.email.emailInvalid && !contactForm.email.$pristine">Incorrect email</span>
                                        </div>

                                        <div class="moto-widget-contact_form-group">
                                            <label for="field_phone" class="moto-widget-contact_form-label">Your
                                                telephone here:</label>
                                            <input type="text"
                                                   class="moto-widget-contact_form-field moto-widget-contact_form-input"
                                                   placeholder="Your telephone here: "
                                                   ng-model-options="{ updateOn: 'blur' }" name="phone" id="field_phone"
                                                   ng-model="message.phone"/>
                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak
                                                  ng-show="contactForm.phone.$invalid && !contactForm.phone.$pristine && !contactForm.phone.emailInvalid">Field is required</span>
                                        </div>


                                        <div class="moto-widget-contact_form-group">
                                            <label for="field_message" class="moto-widget-contact_form-label">Your
                                                comments &amp; questions:</label>
                                            <textarea
                                                    class="moto-widget-contact_form-field moto-widget-contact_form-textarea"
                                                    rows="3" placeholder="Your comments &amp; questions: *"
                                                    ng-blur="validate('message')" required
                                                    ng-model-options="{ updateOn: 'blur' }" name="message"
                                                    id="field_message" ng-model="message.message"></textarea>
                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak
                                                  ng-show="contactForm.message.$invalid && !contactForm.message.$pristine">Field is required</span>
                                        </div>


                                        <div class="moto-widget-contact_form-success ng-cloak" ng-cloak
                                             ng-show="emailSent">
                                            Your message was sent successfully
                                        </div>
                                        <div class="moto-widget-contact_form-danger ng-cloak" ng-cloak
                                             ng-show="emailError">
                                            Sorry, your message was not sent
                                        </div>
                                        <div class="moto-widget-contact_form-buttons">

                                            <div class="moto-widget moto-widget-button moto-preset-4 moto-align-left"
                                                 data-preset="4" data-align="left">
                                                <a ng-click="submit();" class="moto-widget-button-link moto-size-small"
                                                   data-size="small"><span
                                                            class="fa moto-widget-theme-icon"></span><span
                                                            class="moto-widget-button-label">SUBMIT</span></a>
                                            </div>
                                            <button type="submit" class="hidden"></button>

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>