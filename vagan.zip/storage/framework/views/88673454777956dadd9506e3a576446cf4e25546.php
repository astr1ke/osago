
<?php $__env->startSection('content'); ?>
    <a href="/" id="go">
        <img src="<?php echo e(asset('images')); ?>/done-upload.png" style="z-index: 999999;display: block; position:fixed; left:50%;top:50%; margin-left:-100px; margin-top:-100px;" >
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        setTimeout(function() {document.getElementById('go').click()}, 3000);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>