
<?php $__env->startSection('content'); ?>
<section id="section-content" class="content page-3 moto-section" data-widget="section" data-container="section">
    <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto"
         data-widget="row" data-spacing="lala">
        <div class="container-fluid">
            <div class="row">
                <div class="moto-cell col-sm-9" data-container="container">
                    <div data-widget-id="wid__blog_post_list__5b72b2778b02e"
                         class="moto-widget moto-widget-blog-post_list moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto"
                         data-widget="blog.post_list">
                        <ul class="moto-blog-posts-list">
                            <li class="moto-blog-posts-list-item">
                                <article>
                                    <div class="moto-widget moto-widget-row" data-widget="row">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="moto-cell col-sm-12" data-container="container">
                                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                                         data-preset="default">
                                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                                            <h2 class="moto-text_system_7"><a
                                                                        href="/blog/the-most-common-mistakes-when-managing-personal-finances/">The
                                                                    most common mistakes when managing personal
                                                                    finances</a></h2>
                                                        </div>
                                                    </div>
                                                    <div class="moto-widget moto-widget-row" data-widget="row">
                                                        <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="moto-cell col-sm-12"
                                                                     data-container="container">
                                                                    <div data-widget-id="wid__blog_post_published_on__5b72b2778c1fd"
                                                                         class="moto-widget moto-widget-blog-post_published_on moto-preset-default moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto "
                                                                         data-preset="default"
                                                                         data-widget="blog.post_published_on"
                                                                         data-spacing="aasa">
                                                                        <div class="moto-text_system_11">
                                                                            <span class="fa fa-calendar moto-widget-blog-post_published_on-icon"></span>
                                                                            <span class="moto-widget-blog-post_published_on-date">01.12.2016</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div data-widget-id="wid__image__5b72b2778c453"
                                                         class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto  "
                                                         data-widget="image">
                                                        <a class="moto-widget-image-link moto-link"
                                                           href="/blog/the-most-common-mistakes-when-managing-personal-finances/"
                                                           data-action="blog.post">
                                                            <img data-src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img09.jpg"
                                                                 class="moto-widget-image-picture lazyload" data-id=""
                                                                 title="The most common mistakes when managing personal finances"
                                                                 alt="">
                                                        </a>
                                                    </div>
                                                    <div class="moto-blog-post-content moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto">
                                                        <p class="moto-text_normal">The ability to manage money
                                                            competently is especially valuable quality in the conditions
                                                            of financial crisis, when the purchasing power of the
                                                            population is shrinking, inflation is rising, and currency
                                                            exchange rates are completely unpredictable. Below are the
                                                            common mistakes related to money affairs along with
                                                            financial planning advice to help manage your own finances
                                                            properly.<br>
                                                            &nbsp;</p></div>
                                                    <div data-widget-id="wid__button__5b72b2778d1ec"
                                                         class="moto-widget moto-widget-button moto-preset-4 moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto "
                                                         data-widget="button">
                                                        <a href="/blog/the-most-common-mistakes-when-managing-personal-finances/"
                                                           data-action="blog.post"
                                                           class="moto-widget-button-link moto-size-small moto-link"><span
                                                                    class="fa moto-widget-theme-icon"></span> <span
                                                                    class="moto-widget-button-label">READ MORE</span></a>
                                                    </div>
                                                    <div class="moto-widget moto-widget-divider moto-preset-3 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto moto-align-center"
                                                         data-divider-type="horizontal" data-preset="3">
                                                        <hr class="moto-widget-divider-line">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </li>
                            <li class="moto-blog-posts-list-item">
                                <article>
                                    <div class="moto-widget moto-widget-row" data-widget="row">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="moto-cell col-sm-12" data-container="container">
                                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                                         data-preset="default">
                                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                                            <h2 class="moto-text_system_7"><a
                                                                        href="/blog/the-main-objectives-of-the-marketer/">The
                                                                    main objectives of the marketer</a></h2>
                                                        </div>
                                                    </div>
                                                    <div class="moto-widget moto-widget-row" data-widget="row">
                                                        <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="moto-cell col-sm-12"
                                                                     data-container="container">
                                                                    <div data-widget-id="wid__blog_post_published_on__5b72b2778d6ec"
                                                                         class="moto-widget moto-widget-blog-post_published_on moto-preset-default moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto "
                                                                         data-preset="default"
                                                                         data-widget="blog.post_published_on"
                                                                         data-spacing="aasa">
                                                                        <div class="moto-text_system_11">
                                                                            <span class="fa fa-calendar moto-widget-blog-post_published_on-icon"></span>
                                                                            <span class="moto-widget-blog-post_published_on-date">01.12.2016</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div data-widget-id="wid__image__5b72b2778d90f"
                                                         class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto  "
                                                         data-widget="image">
                                                        <a class="moto-widget-image-link moto-link"
                                                           href="/blog/the-main-objectives-of-the-marketer/"
                                                           data-action="blog.post">
                                                            <img data-src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img03.jpg"
                                                                 class="moto-widget-image-picture lazyload" data-id=""
                                                                 title="The main objectives of the marketer" alt="">
                                                        </a>
                                                    </div>
                                                    <div class="moto-blog-post-content moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto">
                                                        <p class="moto-text_normal">The modern market is absolutely
                                                            unpredictable. And yet it lives according to strict laws.
                                                            The marketers need to be known to achieve maximum results in
                                                            their business - that is the main task of the marketer.</p>
                                                    </div>
                                                    <div data-widget-id="wid__button__5b72b2778e312"
                                                         class="moto-widget moto-widget-button moto-preset-4 moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto "
                                                         data-widget="button">
                                                        <a href="/blog/the-main-objectives-of-the-marketer/"
                                                           data-action="blog.post"
                                                           class="moto-widget-button-link moto-size-small moto-link"><span
                                                                    class="fa moto-widget-theme-icon"></span> <span
                                                                    class="moto-widget-button-label">READ MORE</span></a>
                                                    </div>
                                                    <div class="moto-widget moto-widget-divider moto-preset-3 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto moto-align-center"
                                                         data-divider-type="horizontal" data-preset="3">
                                                        <hr class="moto-widget-divider-line">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </li>
                            <li class="moto-blog-posts-list-item">
                                <article>
                                    <div class="moto-widget moto-widget-row" data-widget="row">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="moto-cell col-sm-12" data-container="container">
                                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                                         data-preset="default">
                                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                                            <h2 class="moto-text_system_7"><a
                                                                        href="/blog/methods-of-the-recruitment/">Methods
                                                                    of the recruitment</a></h2>
                                                        </div>
                                                    </div>
                                                    <div class="moto-widget moto-widget-row" data-widget="row">
                                                        <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="moto-cell col-sm-12"
                                                                     data-container="container">
                                                                    <div data-widget-id="wid__blog_post_published_on__5b72b2778e767"
                                                                         class="moto-widget moto-widget-blog-post_published_on moto-preset-default moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto "
                                                                         data-preset="default"
                                                                         data-widget="blog.post_published_on"
                                                                         data-spacing="aasa">
                                                                        <div class="moto-text_system_11">
                                                                            <span class="fa fa-calendar moto-widget-blog-post_published_on-icon"></span>
                                                                            <span class="moto-widget-blog-post_published_on-date">01.12.2016</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div data-widget-id="wid__image__5b72b2778e995"
                                                         class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto  "
                                                         data-widget="image">
                                                        <a class="moto-widget-image-link moto-link"
                                                           href="/blog/methods-of-the-recruitment/"
                                                           data-action="blog.post">
                                                            <img data-src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img08.jpg"
                                                                 class="moto-widget-image-picture lazyload" data-id=""
                                                                 title="Methods of the recruitment" alt="">
                                                        </a>
                                                    </div>
                                                    <div class="moto-blog-post-content moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto">
                                                        <p class="moto-text_normal">Search of staff is not an easy task.
                                                            According to the departmental heads' of personnel management
                                                            words, in order to find a personnel who will correspond to
                                                            the relevant customer needs and requirements, it is
                                                            necessary to carry out a great job.</p></div>
                                                    <div data-widget-id="wid__button__5b72b2778f499"
                                                         class="moto-widget moto-widget-button moto-preset-4 moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto "
                                                         data-widget="button">
                                                        <a href="/blog/methods-of-the-recruitment/"
                                                           data-action="blog.post"
                                                           class="moto-widget-button-link moto-size-small moto-link"><span
                                                                    class="fa moto-widget-theme-icon"></span> <span
                                                                    class="moto-widget-button-label">READ MORE</span></a>
                                                    </div>
                                                    <div class="moto-widget moto-widget-divider moto-preset-3 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto moto-align-center"
                                                         data-divider-type="horizontal" data-preset="3">
                                                        <hr class="moto-widget-divider-line">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </li>
                        </ul>
                        <div class="moto-widget moto-widget-pagination moto-preset-default clearfix moto-spacing-top-small moto-spacing-bottom-small">
                            <ul class="moto-pagination-group moto-pagination-group_pages">
                                <li class="moto-pagination-item moto-pagination-item-page">
                                    <span class="moto-pagination-link moto-pagination-link_active"><span
                                                class="moto-pagination-link-text">1</span></span>
                                </li>
                                <li class="moto-pagination-item moto-pagination-item-page">
                                    <a href="/blog/?page=2" class="moto-pagination-link"><span
                                                class="moto-pagination-link-text">2</span></a>
                                </li>
                            </ul>
                            <ul class="moto-pagination-group moto-pagination-group-controls moto-pagination-group_right">
                                <li class="moto-pagination-item moto-pagination-item-control moto-pagination-item-control_next">
                                    <a href="/blog/?page=2" class="moto-pagination-link"><i
                                                class="moto-pagination-link-icon moto-pagination-link-text fa fa-angle-right"></i></a>
                                </li>
                                <li class="moto-pagination-item moto-pagination-item-control moto-pagination-item-control_last">
                                    <a href="/blog/?page=2" class="moto-pagination-link"><i
                                                class="moto-pagination-link-icon moto-pagination-link-text fa fa-angle-double-right"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="moto-cell col-sm-3" data-container="container">
                    <div data-widget-id="wid__blog_recent_posts__5b72b27790d10"
                         class="moto-widget moto-widget-blog-recent_posts moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto "
                         data-widget="blog.recent_posts">
                        <div class="moto-widget-blog-recent_posts-title">
                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                 data-preset="default" data-spacing="aasa">
                                <div class="moto-widget-text-content moto-widget-text-editable">
                                    <p class="moto-text_system_7">Recent Posts</p>
                                </div>
                            </div>
                        </div>
                        <ul class="moto-widget-blog-recent_posts-list">
                            <li class="moto-widget-blog-recent_posts-item">
                                <div class="moto-widget-blog-recent_posts-item-preview">
                                    <div class="moto-widget moto-widget-image moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="sasa">
                                        <a href="/blog/the-most-common-mistakes-when-managing-personal-finances/"
                                           class="moto-widget-image-link moto-link">
                                            <img src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img09.jpg"
                                                 title="The most common mistakes when managing personal finances"
                                                 class="moto-widget-image-picture">
                                        </a>
                                    </div>
                                </div>
                                <div class="moto-widget-blog-recent_posts-item-title">
                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="aasa">
                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                            <h2 class="blog-post-title moto-text_system_9">
                                                <a href="/blog/the-most-common-mistakes-when-managing-personal-finances/">The
                                                    most common mistakes when managing personal finances</a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="moto-widget-blog-recent_posts-item">
                                <div class="moto-widget-blog-recent_posts-item-preview">
                                    <div class="moto-widget moto-widget-image moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="sasa">
                                        <a href="/blog/the-main-objectives-of-the-marketer/"
                                           class="moto-widget-image-link moto-link">
                                            <img src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img03.jpg"
                                                 title="The main objectives of the marketer"
                                                 class="moto-widget-image-picture">
                                        </a>
                                    </div>
                                </div>
                                <div class="moto-widget-blog-recent_posts-item-title">
                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="aasa">
                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                            <h2 class="blog-post-title moto-text_system_9">
                                                <a href="/blog/the-main-objectives-of-the-marketer/">The main objectives
                                                    of the marketer</a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="moto-widget-blog-recent_posts-item">
                                <div class="moto-widget-blog-recent_posts-item-preview">
                                    <div class="moto-widget moto-widget-image moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="sasa">
                                        <a href="/blog/methods-of-the-recruitment/"
                                           class="moto-widget-image-link moto-link">
                                            <img src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img08.jpg"
                                                 title="Methods of the recruitment" class="moto-widget-image-picture">
                                        </a>
                                    </div>
                                </div>
                                <div class="moto-widget-blog-recent_posts-item-title">
                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="aasa">
                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                            <h2 class="blog-post-title moto-text_system_9">
                                                <a href="/blog/methods-of-the-recruitment/">Methods of the
                                                    recruitment</a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="moto-widget-blog-recent_posts-item">
                                <div class="moto-widget-blog-recent_posts-item-preview">
                                    <div class="moto-widget moto-widget-image moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="sasa">
                                        <a href="/blog/overalls-with-logo-as-a-method-of-advertising/"
                                           class="moto-widget-image-link moto-link">
                                            <img src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img01.jpg"
                                                 title="Overalls with logo as a method of advertising"
                                                 class="moto-widget-image-picture">
                                        </a>
                                    </div>
                                </div>
                                <div class="moto-widget-blog-recent_posts-item-title">
                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="aasa">
                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                            <h2 class="blog-post-title moto-text_system_9">
                                                <a href="/blog/overalls-with-logo-as-a-method-of-advertising/">Overalls
                                                    with logo as a method of advertising</a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="moto-widget-blog-recent_posts-item">
                                <div class="moto-widget-blog-recent_posts-item-preview">
                                    <div class="moto-widget moto-widget-image moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="sasa">
                                        <a href="/blog/recession-is-a-good-opportunity-to-deal-a-deathblow-to-the-competitors/"
                                           class="moto-widget-image-link moto-link">
                                            <img src="<?php echo e(asset('uploads')); ?>/mt-0756_blog_img02.jpg"
                                                 title="Recession is a good opportunity to deal a deathblow to the competitors"
                                                 class="moto-widget-image-picture">
                                        </a>
                                    </div>
                                </div>
                                <div class="moto-widget-blog-recent_posts-item-title">
                                    <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                         data-preset="default" data-spacing="aasa">
                                        <div class="moto-widget-text-content moto-widget-text-editable">
                                            <h2 class="blog-post-title moto-text_system_9">
                                                <a href="/blog/recession-is-a-good-opportunity-to-deal-a-deathblow-to-the-competitors/">Recession
                                                    is a good opportunity to deal a deathblow to the competitors</a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>