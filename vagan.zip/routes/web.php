<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','mainController@welcome');
Route::get('/done','uploadController@done');
Route::get('/upload','uploadController@upload1');
Route::get('/upload2','uploadController@upload2');
Route::get('/upload3','uploadController@upload3');
Route::get('/upload4','uploadController@upload4');
Route::get('/upload5','uploadController@upload5');
Route::post('/upload1','uploadController@upload1post');
Route::post('/upload2','uploadController@upload2post');
Route::post('/upload3','uploadController@upload3post');
Route::post('/upload4','uploadController@upload4post');
Route::post('/upload5','uploadController@upload5post');

