'use strict';

var app = angular.module('angNewsApp', ['ngImageCompress']);

app.controller('demoCtrl', function($scope){
	
})
