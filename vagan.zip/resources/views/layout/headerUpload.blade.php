<header id="section-header" class="header1 moto-section" data-widget="section" data-container="section">
    <div class="moto-widget moto-widget-container moto-container_header_5840279f9e0f2" data-widget="container"
         data-container="container" data-css-name="moto-container_header_5840279f9e0f2">
        <div class="moto-widget moto-widget-container moto-container_header_584aaf961" data-widget="container"
             data-container="container" data-css-name="moto-container_header_584aaf961" data-moto-sticky="{ }">
            <div class="moto-widget moto-widget-row row-fixed moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto"
                 data-widget="row" data-spacing="aaaa">
                <div class="container-fluid">
                    <div class="row">
                        <div class="moto-cell col-sm-5" data-container="container">
                            <div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto"
                                 data-widget="row" data-grid-type="xs" data-spacing="sasa">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="moto-cell col-xs-2" data-container="container">
                                            <div data-widget-id="wid__image__5b7283da4d45c"
                                                 class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  "
                                                 data-widget="image">
                                                <a class="moto-widget-image-link moto-link" href="" data-action="page">
                                                    <img data-src="{{asset('images')}}/icon-header-upload.png" class="moto-widget-image-picture lazyload" data-id="145" title="" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="moto-cell col-xs-10" data-container="container">
                                            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small"
                                                 data-widget="text" data-preset="default" data-spacing="aaas">
                                                <div class="moto-widget-text-content moto-widget-text-editable">
                                                    <p class="moto-text_system_1"><a href="" data-action="page" data-id="9" class="moto-link">Загрузка документов</a>​​​​​​​</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @yield('main')
    </div>
</header>