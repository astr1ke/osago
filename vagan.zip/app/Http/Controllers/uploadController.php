<?php

namespace App\Http\Controllers;

use App\Mail\sendScan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManagerStatic as Image;


class uploadController extends Controller
{
    public function upload1(){
        return view('upload.upload1',['icon'=>'']);
    }
    public function upload1post(Request $request){
        $this->validate($request,[
            'upload1'=>'required',
            'upload2'=>'required',
        ]);
        $user = rand(100,999);

        $userCookie = cookie('userName',$user,60);
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload1'));
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload2'));
        return redirect('/upload2')->cookie($userCookie);
    }

    public function upload2(){
        return view('upload.upload2',['icon'=>'']);
    }
    public function upload2post(Request $request){
        $this->validate($request,[
            'upload1'=>'required',
            'upload2'=>'required',
        ]);
        $user = Cookie::get('userName');
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload1'));
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload2'));
        return redirect('/upload3');
    }

    public function upload3(){
        return view('upload.upload3');
    }
    public function upload3post(Request $request){
        $user = Cookie::get('userName');
        for ($i=1; $i<=8; $i++) {
            unset($scan);
            $scan = $request->file('upload'.$i);
            if (isset($scan)) {
                Storage::disk('local')->putFile('скрины/' . $user, $request->file('upload'.$i));
            }
        }
        if ($request->more == 1){
            return redirect('/upload3');
        }
        return redirect('/upload4');
    }

    public function upload4(){
        return view('upload.upload4');
    }
    public function upload4post(Request $request){
        $this->validate($request,[
            'number'=>'required',
        ]);

        if($request->more == 1){
            $number = $request->number;
            $oldDir = Cookie::get('userName');
            $files = Storage::disk('local')->files('скрины/'.$oldDir);
            Storage::disk('local')->makeDirectory('скрины/'.$number);

            foreach ($files as $file){
                $filePath = strrchr($file,'/');
                Storage::disk('local')->move($file, 'скрины/'.$number.$filePath);
            }
            Storage::disk('local')->deleteDirectory('скрины/'.$oldDir);

            return view('upload.upload5', ['number'=>$request->number,'comment'=>$request->comment]);
        }


        $number = $request->number;
        $oldDir = Cookie::get('userName');
        $files = Storage::disk('local')->files('скрины/'.$oldDir);
        Storage::disk('local')->makeDirectory('скрины/'.$number);

        foreach ($files as $file){
            $f = '../storage/app/'.$file;
            $img = Image::make($f);
            $img->resize(800, 800);
            $ext = substr(strrchr($file,'.'),1);
            $filePath = strrchr($file,'/');
            Storage::disk('local')->put('скрины/'.$number.$filePath, $img->encode($ext, 80));
        }
        Storage::disk('local')->deleteDirectory('скрины/'.$oldDir);


        $sendDir = Storage::disk('local')->files('скрины/'.$number);
        $attach = new sendScan();
        $attach->attach = $sendDir;
        $attach->number = $number;
        $attach->comment = $request->comment;
        Mail::to('mail.usa.va@gmail.com')->send($attach);
        Storage::disk('local')->deleteDirectory('скрины/'.$number);

        return redirect('done');
    }


    public function upload5post(Request $request){
        $user = $request->number;
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload1'));
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload2'));
        Storage::disk('local')->putFile('скрины/'.$user, $request->file('upload3'));

        $number = $request->number;
        $files = Storage::disk('local')->files('скрины/'.$number);

        foreach ($files as $file){
            $f = '../storage/app/'.$file;
            $img = Image::make($f);
            $img->resize(800, 800);
            $ext = substr(strrchr($file,'.'),1);
            $filePath = strrchr($file,'/');
            Storage::disk('local')->put('скрины/'.$number.$filePath, $img->encode($ext, 80));
        }




        $number = $request->number;
        $sendDir = Storage::disk('local')->files('скрины/'.$number);
        $attach = new sendScan();
        $attach->attach = $sendDir;
        $attach->number = $number;
        $attach->comment = $request->comment;
        Mail::to('mail.usa.va@gmail.com')->send($attach);
        Storage::disk('local')->deleteDirectory('скрины/'.$number);


        return redirect('done');
    }

    public function done(){
        return view('upload.done');
    }


}
